# Python Interpreter ComfyUI Node 🐍

![demo video](wiki/demos/videos/demo.gif)

## Description

- Write Python code in a node that executes when the workflow is queued
- The stdout/stderr (e.g., prints, error tracebacks) are displayed in the node. 
- The input values can be accessed by their UI name. 
- The output values are the same as the input values, so modifications you make to the input values will be reflected in the output values.

## Requirements

- python 3.10+

## Installation

1. `cd` int `ComfyUI/custom_nodes` directory
2. `git clone` this repository

## Reason to Use

- Anything that can be done with Python code
- Embedding little scripts into your saved workflows
- Quickly make a node that can do a specialized task
- Converting types
- Doing math with input values
- Debugging
- Testing custom nodes faster.
- Even if you can't code, you can ask ChatGPT to write a python snippet for you to accomplish a tedious task


## Usage

- The variables in the UI (e.g., `image1`, `number1`, `text1`, etc.) can be accessed directly in the code by the same name
    ```python
    print(image1.shape)
    print(number1 * random.randint(0, 99))
    ```
- The output values share the same names as the input values. Changes you make to these variables will be reflected in the output values.
- The code will work as expected in almost all cases except for i. re-assignment and ii. passing the variables as arguments to functions.
  1.  To re-assign a variable, you must use its `to()` method, regardless of the variable's type
      ```python
      # Instead of number1 = float(number1):
      number1.to(float(number1))

      # Instead of image1 = 0.5 * (image1 + image2):
      image1.to(0.5 * (image1 + image2))

      # Instead of mask1 = 1 - mask1:
      mask1.to(1 - mask1)

      # Instead of text1 = text1.replace("bad", ""):
      text1.to(text1.replace("bad", ""))

      # In-place operators (+=, ++, /=, etc.) will work normally
      number1++
      text1 += " is good"
      ```
  2. To pass the variables as arguments to functions, just pass the `.data` attribute of the variable instead (regardless of the variable's type)
      ```python
      # Instead of pil_img = ToPILImage()(image1):
      pil_img = ToPILImage()(image1.data)

      # Instead of random.sample[number1, number2]:
      random.sample([number1.data, number2.data])

      # Not necessary for built-in functions
      print(image1) # works
      print(len(text1)) # works
      ```

## Examples

![demo picture - complementary color palette](wiki/demos/pictures/new-example-complementary-colors.png)

![demo picture = caption composite](wiki/demos/pictures/new-example-caption-draw.png)


- [Automatically get color palette and complements from image](wiki/code-snippets-from-demos/get_complementary_colors.py)
- [Most recent image in folder](wiki/code-snippets-from-demos//most_recent_image_in_folder.py)
- [Paste text on image](wiki/code-snippets-from-demos/paste_text_caption.py)
- ...[More snippets in wiki](wiki/code-snippets-from-demos)

## Advanced Usage Tips

#### Alpha/Masks

- Alpha channels are automatically inverted when loaded in LoadImage nodes. To revert to original: `mask1.to(1 - mask1)`
- You can retrieve the mask from the `mask` output link in the LoadImage node.
- If the original image did not have an alpha channel (it was in RGB format), the LoadImage node will still produce a mask of shaped (64, 64). It's important to understand whether the input image actually has an alpha channel to begin with to avoid confusion.

#### Image/Tensor Types

*If you don't have experience with PyTorch or with making custom nodes, you should read this section.*

- To understand the type and shape of the input images, please refer to the [Images, Latents, and Masks section of comfydocs.org](https://www.comfydocs.org/essentials/custom_node_images_and_masks).
- One thing not mentioned in those docs is that many (most) newer libraries expect tensors as **(B, C, H, W)**, while in Comfy they will be **(B, H, W, C)**. Those libraries/modules include `torchvision` and `fastai`.
  - For example, in the example code from some of the pictures, `torchvision.transforms.ToPILImage()` is used to convert a tensor to a PIL image. Since this is a `torchvision` function, it expects **(B, C, H, W)** format, so the image is converted first using `permute(0, 3, 1, 2)` to change the order of the dimensions. You must then also change it back to its original format using `permute(0, 2, 3, 1)` before retrieving it from the node.
- Additionally, be aware that the terms in the tensor are normalized to the range [0, 1] (torch.float32). To convert to the more manageable/intuitive rgb values of range [0, 255] (torch.uint8), multiply by 255 and cast to `torch.uint8`.

Some helpful strategies:
- To get the color channels: `red, green, blue = image1.unbind(-1)`


#### Imports

You don't need to import modules to use types from those modules. E.g., you don't need to import `torch` to use all the methods of the `torch.Tensor` types. But if you want to access torch methods directly, you can import the module at the top of the code block. 

Imports should behave as expected. If you are running ComfyUI in a virtual environment, you should `pip install` any packages you want to import while in that environment.

#### Re-Assigning to New Types

To understand any bugs that may occur with code you embed, it's best to understand how the input/output variables are handled.

In order to make all data from the inputs reference types that has a closure, all inputs are wrapped in a `Wrapper` class. In essence the `Wrapper` is like an inhertied interface that you may see in a more OOP-esque language. There is an extended wrapper for each builtin python type, as well as for `torch.Tensor` and `torch.nn.Module`.

The wrapper classes are designed the same way as the wrappers in the builtin `collections` module. Those wrappers were made so that programmers could extend primitive types as if they were classes. For example, the `collections.UserString` class is a subclass of `str` that allows you to your own add methods to strings while keeping all other behavior the same. Many languages have similar paradigms, such as the `String` class in Java, which is separate from the primitive `string` type.

Generally this is not somethign to worry about, because the wrapped data is designed to mimic the behavior of the original data. The two caveats are listed in the [Usage](##usage) section (re-assignment and passing variables as arguments to functions). An additional consideration is that while the `to()` method allows you to re-assign variables, if make the input/output variable point at a type that is not the same as the original type, you will lose access to many of that new variable's builtin methods. This is because the wrapper will still be of the original type. For example, if `number1` points to an integer originally, and you then re-assign it to a number, it will still be wrapped by a `NumberWrapper`. Thus, you will not be able to use `number1.split()` or `number1.replace()`. However, you can still use most operators and shared methods and of course you can still access the wrapped data and continue to re-assign it to other types.

This "issue" won't be fixed for various reasons:
- It is extremely rare someone would re-assign an input/output variable to a different type and then try to use that type's builtin methods.
- It can easily be avoided by just using your own variables within the scope of the embedded code. Then to get the data out, assign to an output variable at the very end -- sort of treating the output variables as return statements. 

```python


----

*Disclaimer: Do not put this on a server that is accessible to the public. This node can run any Python code provided by a user, including malicious code.*